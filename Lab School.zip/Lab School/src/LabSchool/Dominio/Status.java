package LabSchool.Dominio;

public enum Status {
    ATIVO,
    IRREGULAR,
    ATENDIMENTO_PEDAGOGICO,
    INATIVO,
    TODOS,
    ERROR,
}
