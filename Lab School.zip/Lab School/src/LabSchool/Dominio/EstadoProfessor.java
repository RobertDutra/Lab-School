package LabSchool.Dominio;

public enum EstadoProfessor {
    ATIVO,
    INATIVO,
    ERROR,
}
