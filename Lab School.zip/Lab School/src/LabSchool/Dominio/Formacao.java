package LabSchool.Dominio;

public enum Formacao {
    GRADUACAO_INCOMPLETA,
    GRADUACAO_COMPLETA,
    MESTRADO,
    DOUTORADO,
    ERROR,
}
