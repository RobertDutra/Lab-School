package LabSchool.Dominio;

public enum Experiencia {
    FRONT_END,
    BACK_END,
    FULL_STACK,
    ERROR,
}
